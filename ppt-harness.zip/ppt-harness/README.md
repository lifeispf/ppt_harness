# ppt-harness

클로드 코드로 **전문가 수준 비즈니스 PPT**를 재현 가능하게 만드는 하네스.
HMG HRD 실무 디자인 관례 × 현대자동차 CI(Hyundai Blue `#002C5F`) 기반 디자인 시스템.

핵심 원칙: **텍스트는 처음부터 끝까지 PowerPoint 네이티브 객체** (SVG/이미지 텍스트 금지),
그래픽은 래스터 에셋, 좌표는 12컬럼 그리드에서 계산으로 파생 — 정렬 문제를 원천 차단한다.

## 파이프라인

```
content/deck.json ──▶ scripts/build.js (pptxgenjs) ──▶ dist/deck.pptx
      ▲                     │
 wireframes/patterns.md     ├─ scripts/chart_highlight.py   차트 포인트 하이라이트 (OOXML dPt 후처리)
 components/index.js        ├─ validate.py                  OOXML 스키마 검증
 tokens.js ◀─ design.md     └─ soffice → pdftoppm → 비전 QA  렌더-검사-수정 루프
```

## 빠른 시작

```bash
npm install
pip install lxml defusedxml Pillow "markitdown[pptx]" --break-system-packages
node scripts/icons.js && node scripts/assets-bg.js   # 에셋 생성 (최초 1회)
node scripts/build.js                                 # → dist/deck.pptx
python scripts/chart_highlight.py dist/deck.pptx 7 8 AEBFD4
python scripts/qa_check.py contrast                   # 자동 QA
```

전체 절차·QA 체크리스트는 [SKILL.md](SKILL.md) — 클로드 코드 커스텀 스킬로 그대로 사용 가능
(`.claude/skills/ppt-harness/`에 폴더 배치).

## 구조

| 경로 | 역할 |
|---|---|
| `design.md` | 사람이 읽는 디자인 시스템 (팔레트·타이포·서페이스·금지 규칙) |
| `tokens.js` | design.md를 컴파일한 단일 소스 — 모든 색·크기·좌표의 출처 |
| `wireframes/patterns.md` | 레이아웃 패턴 스펙 (슬롯 스키마 + 스케치) |
| `components/index.js` | 패턴 구현 — cover / agenda / kpis(히어로) / chartStory / dataTable / composition / sectionDivider / roadmap / closing |
| `content/deck.json` | 콘텐츠 스펙 (콘텐츠/디자인 분리) — 덱 교체는 이 파일만 |
| `scripts/` | 빌드·에셋·차트 하이라이트·자동 QA |
| `assets/` | 아이콘(react-icons→PNG)·배경(그라데이션/커버 아트) |

## 디자인 시스템 요약

- 블루 모노크롬: `002C5F`(지배) → `0070AB` → `00A1C7` → `AEBFD4` — "진할수록 핵심"
- 어서션 타이틀(≤22자), 히어로 위계, 차트 하이라이트 — 슬라이드마다 주인공 하나
- 서페이스: 그레이 페이지 + 화이트 카드(헤어라인+미세 그림자), 다크는 그라데이션
- HRD 시그니처: Key Implication 밴드, ▲royal/▼burnt 증감, Tier 필 배지
- 폰트: Malgun Gothic 기본, Hyundai Sans KR 교체 가능 (`tokens.js`)

수치·기업명은 데모용 가상 데이터입니다.
