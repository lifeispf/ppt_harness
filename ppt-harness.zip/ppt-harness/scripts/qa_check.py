#!/usr/bin/env python3
"""자동 QA — 광학·정합 검사 (design.md §8 '대비 실측' + §4 '정렬은 계산으로')

사용법:
  python scripts/qa_check.py contrast
      tokens.js의 색 조합(실사용 쌍)에 대해 WCAG 대비를 실측한다.
      본문 텍스트 4.5:1, 대형/볼드·보조 라벨 3.0:1 기준. FAIL 발생 시 exit 1.

  python scripts/qa_check.py grid <렌더된 slide-N.jpg> <y_inch>
      렌더 이미지의 y(인치) 수평선에서 카드 엣지를 검출해
      12컬럼 그리드 라인과의 편차를 보고한다 (정보성 · exit 0).
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ---------- 공통 ----------

def load_tokens():
    src = (ROOT / "tokens.js").read_text(encoding="utf-8")
    colors = dict(re.findall(r'(\w+):\s*"([0-9A-Fa-f]{6})"', src))
    return colors


def luminance(hexv):
    def lin(c):
        c = c / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (int(hexv[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def ratio(fg, bg):
    l1, l2 = sorted([luminance(fg), luminance(bg)], reverse=True)
    return (l1 + 0.05) / (l2 + 0.05)


# ---------- contrast ----------

# (전경, 배경, 용도, 최소 기준) — 컴포넌트의 실사용 조합. 새 조합 도입 시 여기 추가.
PAIRS = [
    ("white", "primary", "다크 배경 본문/칩 글자", 4.5),
    ("ice", "primary", "다크 배경 보조 텍스트", 4.5),
    ("white", "royal", "royal 배지 글자", 4.5),
    ("primary", "sky", "sky 칩/배지 글자(네이비)", 4.5),
    ("primary", "steel", "steel 배지 글자(네이비)", 4.5),
    ("ink", "white", "카드 위 헤딩", 4.5),
    ("body", "white", "카드 위 본문", 4.5),
    ("royal", "white", "KI 라벨·콜아웃·▲증가", 4.5),
    ("neg", "white", "▼감소/GAP 텍스트", 4.5),
    ("muted", "white", "카드 위 라벨·캡션", 4.5),
    ("body", "bgSoft", "페이지 위 본문", 4.5),
    ("muted", "bgSoft", "페이지 위 캡션(보조·10pt 내외)", 3.0),
    ("primary", "bgSoft", "페이지 위 타이틀(36pt bold)", 3.0),
    ("royal", "surface", "KI 밴드 라벨", 4.5),
]


def cmd_contrast():
    colors = load_tokens()
    fails = 0
    print(f"{'전경/배경':<18}{'대비':>7}  {'기준':>5}  판정  용도")
    for fg, bg, use, need in PAIRS:
        if fg not in colors or bg not in colors:
            print(f"{fg}/{bg:<12}   -      -   SKIP  토큰 없음")
            continue
        r = ratio(colors[fg], colors[bg])
        ok = r >= need
        fails += 0 if ok else 1
        print(f"{fg + '/' + bg:<18}{r:>6.2f}:1  {need:>4.1f}  {'PASS' if ok else 'FAIL'}  {use}")
    print(f"\n{'모두 통과' if fails == 0 else f'FAIL {fails}건 — tokens.js 또는 사용처를 수정할 것'}")
    sys.exit(1 if fails else 0)


# ---------- grid ----------

def cmd_grid(img_path, y_inch):
    from PIL import Image

    img = Image.open(img_path).convert("L")
    W, H = img.size
    dpi = W / 13.333
    y = int(float(y_inch) / 7.5 * H)

    row = [img.getpixel((x, y)) for x in range(W)]
    edges = []
    for x in range(2, W - 2):
        if abs(row[x + 2] - row[x - 2]) > 14:
            if not edges or x - edges[-1] > 6:
                edges.append(x)

    margin, gutter, cols = 0.6, 0.2, 12
    colw = (13.333 - margin * 2 - gutter * (cols - 1)) / cols
    grid = [margin + i * (colw + gutter) for i in range(cols)]
    grid += [g + colw for g in grid] + [13.333 - margin]

    print(f"검출 엣지 {len(edges)}개 @ y={y_inch}\" (허용 편차 0.05\")")
    off = 0
    for e in edges:
        xi = e / dpi
        d = min(abs(xi - g) for g in grid)
        if d > 0.05:
            off += 1
            print(f"  off-grid: x={xi:.3f}\" (최근접 그리드와 {d:.3f}\" 차이)")
    print("모든 엣지가 그리드에 정합" if off == 0 else f"off-grid {off}건 — 의도된 요소(칩·바)인지 확인")


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "contrast":
        cmd_contrast()
    elif len(sys.argv) == 4 and sys.argv[1] == "grid":
        cmd_grid(sys.argv[2], sys.argv[3])
    else:
        sys.exit(__doc__)
