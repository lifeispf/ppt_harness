// scripts/assets-bg.js — 다크 슬라이드용 배경 에셋 생성 (SVG → PNG).
// pptxgenjs는 그라데이션 필 미지원 → 이미지 배경으로 우회 (design.md §5).
// 규칙: 배경 SVG에 텍스트 금지.

const fs = require("fs");
const path = require("path");
const sharp = require("sharp");

const OUT = path.join(__dirname, "..", "assets", "bg");
fs.mkdirSync(OUT, { recursive: true });

const GRAD = `<defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
<stop offset="0%" stop-color="#0E4A86"/>
<stop offset="52%" stop-color="#002C5F"/>
<stop offset="100%" stop-color="#001736"/>
</linearGradient></defs>`;

// 1) dark-gradient.png — 디바이더·클로징용 기본 다크 배경
const gradient = `<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080">
${GRAD}<rect width="1920" height="1080" fill="url(#g)"/></svg>`;

// 2) cover-art.png — 표지용: 그라데이션 + 동심원 링 (서클 모티프의 절제된 변주)
const rings = [];
for (let i = 0; i < 10; i++) {
  const r = 180 + i * 84;
  rings.push(`<circle cx="1580" cy="220" r="${r}" fill="none" stroke="#B8CFE8" stroke-opacity="0.08" stroke-width="1.6"/>`);
}
for (let i = 0; i < 5; i++) {
  const r = 110 + i * 66;
  rings.push(`<circle cx="120" cy="1040" r="${r}" fill="none" stroke="#B8CFE8" stroke-opacity="0.05" stroke-width="1.4"/>`);
}
const coverArt = `<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080">
${GRAD}<rect width="1920" height="1080" fill="url(#g)"/>${rings.join("")}</svg>`;

(async () => {
  await sharp(Buffer.from(gradient)).png().toFile(path.join(OUT, "dark-gradient.png"));
  console.log("bg: dark-gradient.png");
  await sharp(Buffer.from(coverArt)).png().toFile(path.join(OUT, "cover-art.png"));
  console.log("bg: cover-art.png");
})();
